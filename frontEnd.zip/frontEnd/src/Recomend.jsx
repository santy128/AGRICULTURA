import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import './recomend.css'
import fert from './fet.jpg'
export const Recomend = () => {

    const [data,setData] = useState([]);


    // useEffect(() => {
    //     fetch('http://localhost:8081/rec')
    //     //   .then(response => response.json())
    //     //   .then(data => console.log(data))
          
    //     //   .catch(error => console.error('Error fetching data:', error));
    //     //   const data = JSON.stringify(response.data);
    //     // const array = JSON.parse(data).array;
    //     // setData(array);
    //     .then(function (response) {
    //         const data = JSON.stringify(response.data);
    //         const array = JSON.parse(data).array;
    //         setData(array);
    //       })
    //       console.log(data);
    //   }, []);


    // const fetchInfo = () => {
    //     return fetch('http://localhost:8081/rec')
    //       .then((res) => res.json())
    //       .then((d) => setData(d))
    //   }
    
    
    //   useEffect(() => {
    //     fetchInfo();
    //   }, []);
    //   console.log("Resultent Data",data)


    // useEffect(()=>{

    //     console.log("Resultent DATa")

       

    // //     fetch('http://localhost:8081/rec')
    // //     .then(res=> res.json())
    // //     .then(data=> console.log(data))
    // //     .catch(err => console.log(err))
    // //     setData(res.data);
    // //     console.log("Resultent Data",data);
    //   }, [])
  return (
    <div>
        <div className="nav-parent">
  <div className="nav-wrapper">
    <div className="branding">
      <a href="#">Fertilizer Recommentation</a>
    </div>
    
    <ul>
      <li><Link to={'/'}>Home</Link></li>
      <li><Link to={'/fertilize'}>Fertilizer Recomend</Link></li>
    </ul>
    
       <a className="burger">
        <div className="bar"></div>
        <div className="bar"></div>
      </a>
  </div>
</div>
<div className='recomend'>
<div className="card">
      <div className="image">
        <img
        src={fert}
      />
      </div>
      {
        data.map((item,index)=>{
            <p key={index}>{item.fertilizername}</p>
        })
      }
     <h3>Recommended Fertilizer : <span>Urea</span></h3>
      <p>
      A fertilizer or fertiliser is any material of natural or synthetic origin that is applied to soil or to plant tissues to supply plant nutrients. Fertilizers may be distinct from liming materials
       or other non-nutrient soil amendments. Many sources of fertilizer exist, both natural and industrially produced
      </p>
     
    </div>
</div>
    </div>
  )
}
