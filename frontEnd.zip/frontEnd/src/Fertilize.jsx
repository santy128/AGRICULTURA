import React, { useState,useEffect } from 'react'
import { Link, useNavigate  } from 'react-router-dom';
import './fertilize.css'

function Fertilize() {

  const [nitrogen , setNitrogen] = useState('');
  const[potassium , setPotassium] = useState('');
  const[phosphorous , setPhosphorus] = useState('');
  const[temperature , setTemperature] = useState('');
  const[humidity , setHumidity] = useState('');
  const[moisture , setMoisture] = useState('');
  const[soiltype , setSoiltype] = useState('');
  const[croptype , setcroptype] = useState('');
  const history = useNavigate ();
  const[data,setData] = useState('');

const handleSubmit = (e) =>{
  e.preventDefault();
  const pdata = {nitrogen,potassium,phosphorous,temperature,humidity,moisture,soiltype,croptype}
  console.log("BEfore Setting")
  fetch('http://localhost:8081/recomend' , {
    method: 'POST',
    headers: { "Content-Type" : "application/json" },
    body: JSON.stringify(pdata)
    
  }).then(response => response.json())
  .then(data => console.log(rows))
  console.log("after Setting");
  history('/recomend')
}

//  useEffect(() => {
//          fetch('http://localhost:8081/recomend')
//            .then(response => response.json())
//             .then(data => console.log(data))
//           console.log('data reult')
   
//       }, []);

  return (
    <div>

<div className="nav-parent">
  <div className="nav-wrapper">
    <div className="branding">
      <a href="#">Fertilizer Recommentation</a>
    </div>
    
    <ul>
    <li><Link to={'/'}>Home</Link></li>
    <li><Link to={'/fertilize'}>Fertilizer Recomend</Link></li>
     
    </ul>
    
       <a className="burger">
        <div className="bar"></div>
        <div className="bar"></div>
      </a>
  </div>
</div>
<div className='form-back'>
<form className="form" onSubmit={handleSubmit}>
<div className="box">
    <h2>Fertilizer Recommender
    </h2>
    
      <div className="inputBox">
        <input type="text" value={nitrogen} onChange={(e)=> setNitrogen(e.target.value)} name="" required/>
        <label>Amount Of Nitrogen in Soil</label>
      </div>
      <div className="inputBox">
        <input type="text" value={potassium} onChange={(e)=> setPotassium(e.target.value)} name="" required/>
        <label>Amount Of Potassium in Soil</label>
      </div>
      <div className="inputBox">
        <input type="text" value={phosphorous} onChange={(e)=> setPhosphorus(e.target.value)} name="" required/>
        <label>Amount Of phosphorous in Soil</label>
      </div>
      <div className="inputBox">
        <input type="text" value={temperature} onChange={(e)=> setTemperature(e.target.value)} name="" required/>
        <label>Temperature in (Celcius)</label>
      </div>
      <div className="inputBox">
        <input type="text" value={humidity} onChange={(e)=> setHumidity(e.target.value)} name="" required/>
        <label>Humidity in (%)</label>
      </div>
      <div className="inputBox">
        <input type="text" value={moisture} onChange={(e)=> setMoisture(e.target.value)} name="" required/>
        <label>Moisture In Soil</label>
      </div>
      
      <div className="inputBox">
        
      <select value={soiltype} onChange={(e)=> setSoiltype(e.target.value)} name="soiltype" id="" className="form-control">
          <option value="#">Select Soil Type</option>
          <option value="sandy">Sandy</option>
          <option value="Loamy">Loamy</option>
          <option value="Red">Red</option>
          <option value="Black">Black</option>
          <option value="Clayey">Clayey</option>
      </select>
     
      </div>
      <div className="inputBox">
        
      <select value={croptype} onChange={(e)=>setcroptype(e.target.value)} name="croptype" id="" className="form-control">
          <option value="#">Select Crop Type</option>
          <option value="Maize">Maize</option>
          <option value="Sugarcane">Sugarcane</option>
          <option value="Cotton">Cotton</option>
          <option value="Paddy">Paddy</option>
          <option value="Barley">Barley</option>
          <option value="Wheat">Wheat</option>
          <option value="Millets">Millets</option>
          <option value="Oil Seeds">Oil seeds</option>
      </select>
     
      </div>
      <input type="submit" value="Submit"/>
    
  </div>
</form>
</div>
    </div>
  )
}

export default Fertilize