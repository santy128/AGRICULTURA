import React from 'react'
import './Home.css'
import { Link } from 'react-router-dom'

export const Home = () => {
  return (
    <div>

<div class="nav-parent">
  <div class="nav-wrapper">
    <div class="branding">
      <a href="#">Fertilizer Recommentation</a>
    </div>
    
    <ul>
      <li><Link to={'/'}>Home</Link></li>
      <li><Link to={'/fertilize'}>Fertilizer Recomend</Link></li>
    </ul>
    
       <a class="burger" onclick="burgerButton()">
        <div class="bar"></div>
        <div class="bar"></div>
      </a>
  </div>
</div>

         <header class="hero">
        <div class="hero-content">
            <h1 class="hero-title">Fertilizer Recomentation System For Crops</h1>
            <p class="hero-subtitle">Here YOu Can get Your Fertilizer Sugesstions</p>
            <Link to={'/fertilize'} class="hero-button">Get Started</Link>
        </div>
    </header>
    </div>
  )
}
