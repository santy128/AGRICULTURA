import React, { useEffect } from 'react'
import { Home } from './Home'
import {BrowserRouter, Route, Routes} from 'react-router-dom'
import Fertilize from './Fertilize'
import { Recomend } from './Recomend'

function App() {

  useEffect(()=>{
    fetch('http://localhost:8081/fertilizer')
    .then(res=> res.json())
    .then(data=> console.log(data))
    .catch(err => console.log(err))
  }, [])

  return (
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path='/fertilize' element={<Fertilize/>}/>
      <Route path='/recomend' element={<Recomend/>}/>
    </Routes>
    </BrowserRouter>
    
  )
}

export default App